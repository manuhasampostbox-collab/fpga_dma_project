// 8N1 UART receiver and transmitter (CLKS_PER_BIT = clock / baud).
module uart_rx #(parameter int CLKS_PER_BIT = 104) (
  input  logic clk, rst_n, rx,
  output logic [7:0] data,
  output logic valid
);
  typedef enum logic [1:0] {IDLE, START, BITS, STOP} st_t;
  st_t st; logic [15:0] cnt; logic [2:0] idx; logic [7:0] sh; logic rx_s1, rx_s2;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin st <= IDLE; cnt <= 0; idx <= 0; sh <= 0; data <= 0; valid <= 0; rx_s1 <= 1; rx_s2 <= 1; end
    else begin
      rx_s1 <= rx; rx_s2 <= rx_s1; valid <= 0;
      unique case (st)
        IDLE:  if (!rx_s2) begin st <= START; cnt <= 0; end
        START: if (cnt == CLKS_PER_BIT/2) begin
                 if (!rx_s2) begin st <= BITS; cnt <= 0; idx <= 0; end else st <= IDLE;
               end else cnt <= cnt + 1;
        BITS:  if (cnt == CLKS_PER_BIT-1) begin
                 cnt <= 0; sh <= {rx_s2, sh[7:1]};
                 if (idx == 7) st <= STOP; else idx <= idx + 1;
               end else cnt <= cnt + 1;
        STOP:  if (cnt == CLKS_PER_BIT-1) begin
                 st <= IDLE; cnt <= 0;
                 if (rx_s2) begin data <= sh; valid <= 1; end
               end else cnt <= cnt + 1;
      endcase
    end
  end
endmodule

module uart_tx #(parameter int CLKS_PER_BIT = 104) (
  input  logic clk, rst_n,
  input  logic [7:0] data,
  input  logic start,
  output logic tx,
  output logic busy
);
  logic [9:0] sh; logic [15:0] cnt; logic [3:0] n;
  assign busy = (n != 0);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin sh <= 10'h3FF; cnt <= 0; n <= 0; tx <= 1; end
    else if (n == 0) begin
      tx <= 1;
      if (start) begin sh <= {1'b1, data, 1'b0}; n <= 10; cnt <= 0; end
    end else begin
      tx <= sh[0];
      if (cnt == CLKS_PER_BIT-1) begin cnt <= 0; sh <= {1'b1, sh[9:1]}; n <= n - 1; end
      else cnt <= cnt + 1;
    end
  end
endmodule
