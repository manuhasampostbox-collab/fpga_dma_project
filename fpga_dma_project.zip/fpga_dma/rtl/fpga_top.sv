// UART-controlled DMA SoC for an iCE40 FPGA: UART -> bridge -> APB -> DMA, 4 KB RAM (block RAM).
module fpga_top #(parameter int CLKS_PER_BIT = 104) (   // 12 MHz / 115200
  input  logic clk,
  input  logic rx,
  output logic tx,
  output logic led_irq_n,      // active low LED: lit when the DMA interrupt is pending
  output logic led_busy_n      // active low LED: lit while the DMA is using the RAM
);
  // power-on reset (no reset pin on the board)
  logic [3:0] rst_cnt = 4'd0;
  logic rst_n;
  always_ff @(posedge clk) if (rst_cnt != 4'hF) rst_cnt <= rst_cnt + 1;
  assign rst_n = (rst_cnt == 4'hF);

  logic [7:0] rx_data, tx_data; logic rx_valid, tx_start, tx_busy;
  uart_rx #(CLKS_PER_BIT) u_rx (.clk, .rst_n, .rx, .data(rx_data), .valid(rx_valid));
  uart_tx #(CLKS_PER_BIT) u_tx (.clk, .rst_n, .data(tx_data), .start(tx_start), .tx, .busy(tx_busy));

  logic psel, penable, pwrite; logic [7:0] paddr; logic [31:0] pwdata, prdata; logic pready, pslverr;
  logic ram_req, ram_we, ram_grant; logic [9:0] ram_idx; logic [31:0] ram_wdata, ram_rdata_b;
  uart_bridge u_br (.clk, .rst_n, .rx_data, .rx_valid, .tx_data, .tx_start, .tx_busy,
                    .psel, .penable, .pwrite, .paddr, .pwdata, .prdata,
                    .ram_req, .ram_we, .ram_idx, .ram_wdata, .ram_grant, .ram_rdata(ram_rdata_b));

  logic mem_en, mem_we, irq; logic [31:0] mem_addr, mem_wdata, mem_rdata;
  dma_ctrl #(.MEM_BYTES(4096)) u_dma (.clk, .rst_n, .psel, .penable, .pwrite, .paddr, .pwdata, .prdata,
                                      .pready, .pslverr, .mem_en, .mem_we, .mem_addr, .mem_wdata,
                                      .mem_rdata, .irq);

  // single-port RAM: the DMA has priority, the bridge gets the port when the DMA is idle
  assign ram_grant = ram_req & ~mem_en;
  logic        en, we; logic [9:0] a; logic [31:0] wd;
  always_comb begin
    en = mem_en | ram_grant;
    we = mem_en ? mem_we : (ram_grant & ram_we);
    a  = mem_en ? mem_addr[11:2] : ram_idx;
    wd = mem_en ? mem_wdata : ram_wdata;
  end
  logic [31:0] ram [1024];
  logic [31:0] rdata;
  always_ff @(posedge clk) begin
    if (en) begin
      if (we) ram[a] <= wd;
      rdata <= ram[a];
    end
  end
  assign mem_rdata   = rdata;
  assign ram_rdata_b = rdata;

  assign led_irq_n  = ~irq;
  assign led_busy_n = ~mem_en;
endmodule
