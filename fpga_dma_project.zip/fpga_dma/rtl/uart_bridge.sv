// UART-to-APB/memory bridge. Frame from the host (all multi-byte fields big-endian):
//   'W' addr16 data32  -> APB register write, reply 0x06
//   'R' addr16         -> APB register read,  reply 4 bytes
//   'P' addr16 data32  -> RAM poke (word index), reply 0x06
//   'Q' addr16         -> RAM peek (word index), reply 4 bytes
module uart_bridge (
  input  logic clk, rst_n,
  input  logic [7:0] rx_data, input logic rx_valid,
  output logic [7:0] tx_data, output logic tx_start, input logic tx_busy,
  // APB master
  output logic psel, penable, pwrite, output logic [7:0] paddr, output logic [31:0] pwdata,
  input  logic [31:0] prdata,
  // RAM access (only granted when the DMA is not using the RAM)
  output logic ram_req, ram_we, output logic [9:0] ram_idx, output logic [31:0] ram_wdata,
  input  logic ram_grant, input logic [31:0] ram_rdata
);
  typedef enum logic [3:0] {IDLE, AH, AL, D3, D2, D1, D0, EXEC_APB, APB_ACC, EXEC_RAM, RAM_WAIT, RAM_RD, REPLY} st_t;
  st_t st;
  logic [7:0] cmd; logic [15:0] addr; logic [31:0] data; logic [2:0] rbytes; logic [1:0] sidx;
  logic [31:0] rsp; logic [2:0] rleft;
  logic is_write;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= IDLE; cmd <= 0; addr <= 0; data <= 0; psel <= 0; penable <= 0; pwrite <= 0;
      paddr <= 0; pwdata <= 0; ram_req <= 0; ram_we <= 0; ram_idx <= 0; ram_wdata <= 0;
      tx_start <= 0; tx_data <= 0; rsp <= 0; rleft <= 0; is_write <= 0;
    end else begin
      tx_start <= 0;
      unique case (st)
        IDLE: if (rx_valid) begin
          cmd <= rx_data;
          if (rx_data == "W" || rx_data == "R" || rx_data == "P" || rx_data == "Q") st <= AH;
        end
        AH: if (rx_valid) begin addr[15:8] <= rx_data; st <= AL; end
        AL: if (rx_valid) begin
          addr[7:0] <= rx_data;
          is_write <= (cmd == "W" || cmd == "P");
          if (cmd == "W" || cmd == "P") st <= D3;
          else st <= (cmd == "R") ? EXEC_APB : EXEC_RAM;
        end
        D3: if (rx_valid) begin data[31:24] <= rx_data; st <= D2; end
        D2: if (rx_valid) begin data[23:16] <= rx_data; st <= D1; end
        D1: if (rx_valid) begin data[15:8]  <= rx_data; st <= D0; end
        D0: if (rx_valid) begin data[7:0]   <= rx_data; st <= (cmd == "W") ? EXEC_APB : EXEC_RAM; end
        EXEC_APB: begin
          psel <= 1; penable <= 0; pwrite <= is_write; paddr <= addr[7:0]; pwdata <= data; st <= APB_ACC;
        end
        APB_ACC: begin
          if (!penable) penable <= 1;
          else begin
            psel <= 0; penable <= 0; pwrite <= 0;
            if (is_write) begin rsp <= 32'h06; rleft <= 1; end
            else begin rsp <= prdata; rleft <= 4; end
            st <= REPLY; sidx <= 0;
          end
        end
        EXEC_RAM: begin
          ram_req <= 1; ram_we <= is_write; ram_idx <= addr[9:0]; ram_wdata <= data; st <= RAM_WAIT;
        end
        RAM_WAIT: if (ram_grant) begin
          ram_req <= 0; ram_we <= 0;
          if (is_write) begin rsp <= 32'h06; rleft <= 1; st <= REPLY; end
          else st <= RAM_RD;                         // sync read: data valid one cycle later
        end
        RAM_RD: begin rsp <= ram_rdata; rleft <= 4; st <= REPLY; end
        REPLY: begin
          if (rleft == 0) st <= IDLE;
          else if (!tx_busy && !tx_start) begin
            tx_data <= (rleft == 1 && is_write) ? 8'h06 : rsp[31:24];
            tx_start <= 1;
            rsp <= (is_write) ? rsp : {rsp[23:0], 8'h00};
            rleft <= rleft - 1;
          end
        end
        default: st <= IDLE;
      endcase
    end
  end
endmodule
