// Self-checking testbench: a "PC" talks to fpga_top over UART, exactly as it would on the board.
`timescale 1ns/1ps
module tb;
  localparam int CPB = 8;                       // clocks per UART bit (fast for simulation)
  logic clk = 0, rx = 1, tx, led_irq_n, led_busy_n;
  fpga_top #(.CLKS_PER_BIT(CPB)) dut (.clk, .rx, .tx, .led_irq_n, .led_busy_n);
  always #5 clk = ~clk;

  int errors = 0, checks = 0;
  task automatic check(input bit c, input string m);
    checks++; if (!c) begin errors++; $display("[FAIL] %s", m); end
  endtask

  task automatic uart_send(input logic [7:0] b);
    rx = 0; repeat (CPB) @(posedge clk);
    for (int i = 0; i < 8; i++) begin rx = b[i]; repeat (CPB) @(posedge clk); end
    rx = 1; repeat (CPB) @(posedge clk);
  endtask

  task automatic uart_recv(output logic [7:0] b);
    @(negedge tx);
    repeat (CPB + CPB/2) @(posedge clk);
    for (int i = 0; i < 8; i++) begin b[i] = tx; repeat (CPB) @(posedge clk); end
  endtask

  task automatic send_frame(input byte cmd, input int unsigned addr, input bit has_data, input logic [31:0] d);
    uart_send(cmd); uart_send(addr[15:8]); uart_send(addr[7:0]);
    if (has_data) begin uart_send(d[31:24]); uart_send(d[23:16]); uart_send(d[15:8]); uart_send(d[7:0]); end
  endtask

  task automatic wait_ack(input string what);
    logic [7:0] b; uart_recv(b); check(b == 8'h06, {what, ": ack"});
  endtask

  task automatic wr_reg(input int unsigned a, input logic [31:0] d);
    send_frame("W", a, 1, d); wait_ack("write reg");
  endtask
  task automatic rd_reg(input int unsigned a, output logic [31:0] d);
    logic [7:0] b0, b1, b2, b3;
    send_frame("R", a, 0, 0); uart_recv(b0); uart_recv(b1); uart_recv(b2); uart_recv(b3); d = {b0, b1, b2, b3};
  endtask
  task automatic poke(input int unsigned idx, input logic [31:0] d);
    send_frame("P", idx, 1, d); wait_ack("poke");
  endtask
  task automatic peek(input int unsigned idx, output logic [31:0] d);
    logic [7:0] b0, b1, b2, b3;
    send_frame("Q", idx, 0, 0); uart_recv(b0); uart_recv(b1); uart_recv(b2); uart_recv(b3); d = {b0, b1, b2, b3};
  endtask

  task automatic run_dma(input int unsigned src, input int unsigned dst, input int unsigned len,
                         input bit irq_en, output logic [31:0] status);
    wr_reg(8'h00, src); wr_reg(8'h04, dst); wr_reg(8'h08, len); wr_reg(8'h0C, {30'b0, irq_en, 1'b1});
    do rd_reg(8'h10, status); while (status[0]);
  endtask

  function automatic logic [31:0] pat(input int unsigned s, input int unsigned i);
    return s ^ (i * 32'h9E3779B1);
  endfunction

  logic [31:0] st, got;

  initial begin
    repeat (40) @(posedge clk);                  // power-on reset in fpga_top
    // 1) register access over UART
    rd_reg(8'h10, st); check(st == 0, "STATUS is 0 after reset");
    wr_reg(8'h08, 32'h1234); rd_reg(8'h08, got); check(got == 32'h1234, "LEN register read-back");
    // 2) RAM poke/peek
    poke(10'd5, 32'hCAFEF00D); peek(10'd5, got); check(got == 32'hCAFEF00D, "RAM poke/peek");
    // 3) a DMA transfer driven entirely from the "PC"
    for (int i = 0; i < 8; i++) poke(16 + i, pat(32'hA5A50000, i));
    run_dma(32'h40, 32'h100, 8, 1, st);
    check(st[1] && !st[2] && !st[0], "DMA done flag");
    check(led_irq_n == 0, "irq LED lit");
    for (int i = 0; i < 8; i++) begin peek(64 + i, got); check(got == pat(32'hA5A50000, i), $sformatf("dst word %0d", i)); end
    wr_reg(8'h14, 3);
    repeat (4) @(posedge clk); check(led_irq_n == 1, "irq LED off after clear");
    // 4) a few random transfers
    for (int it = 0; it < 6; it++) begin
      int unsigned len = $urandom_range(1, 24), s = 4 * $urandom_range(0, 100), d = 4 * $urandom_range(300, 400), seed = $urandom;
      for (int i = 0; i < len; i++) poke(s/4 + i, pat(seed, i));
      run_dma(s, d, len, 0, st);
      check(st[1] && !st[2], $sformatf("random %0d: done", it));
      for (int i = 0; i < len; i++) begin peek(d/4 + i, got); check(got == pat(seed, i), $sformatf("random %0d word %0d", it, i)); end
      wr_reg(8'h14, 3);
    end
    // 5) error: zero length
    run_dma(32'h40, 32'h100, 0, 0, st);
    wr_reg(8'h0C, 1); rd_reg(8'h10, st);
    check(st[2], "zero length sets ERR");
    $display("checks: %0d  errors: %0d", checks, errors);
    if (errors == 0) $display("RESULT: PASS"); else $display("RESULT: FAIL");
    $finish;
  end
  initial begin #200_000_000; $display("RESULT: FAIL (global timeout)"); $finish; end
endmodule
